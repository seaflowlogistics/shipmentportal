export default function Clearance() {
  return (
    <div>
      <h2 className="text-2xl font-bold mb-4">Clearance</h2>
      <p className="text-gray-700">
        This page will later show scheduled clearance, delivery notes, and status
        updates.
      </p>
    </div>
  );
}
