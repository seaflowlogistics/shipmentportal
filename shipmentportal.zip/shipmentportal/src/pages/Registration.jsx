export default function Registration() {
  return (
    <div>
      <h2 className="text-2xl font-bold mb-4">Registration</h2>
      <p className="text-gray-700">
        Here we’ll build the shipment registration form (TYPE, METHOD, CUSTOMER,
        EXPORTER, BILLING...).
      </p>
    </div>
  );
}
