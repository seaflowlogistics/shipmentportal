export default function Accounts() {
  return (
    <div>
      <h2 className="text-2xl font-bold mb-4">Accounts</h2>
      <p className="text-gray-700">
        Here we’ll add pending / approved payments, vendors, and vouchers.
      </p>
    </div>
  );
}
