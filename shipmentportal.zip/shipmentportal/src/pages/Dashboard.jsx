export default function Dashboard() {
  return (
    <div>
      <h2 className="text-2xl font-bold mb-4">Dashboard</h2>
      <p className="text-gray-700">
        This is your base dashboard. We’ll later replace this with shipment
        statistics and cards based on your design.
      </p>
    </div>
  );
}
